  
# Moikka!  
  
Kiitos paljon viestistä ja haastattelukutsusta. Kiva kuulla, että nimi oli vielä muistissa! :D  
  
Ilmoitan nyt jo etukäteen, että olen edelleen kiinnostunut Bootcampista kesälle 2026, mutta koska siihen pääsy varmistuu vasta keväällä, haluan myös selvittää mahdollisuudet päivystäjän tehtävään. Mikäli Bootcamp varmistuu ja minut valitaan siihen, se olisi ensisijainen vaihtoehtoni, mutta tällä hetkellä olen avoin päivystäjän työtehtävälle. Tiedustelisin siis, että mikä on aikaisin ajankohta jolloin tuo Bootcampin paikka varmistuu?  
  
Nähdään siis maanantaina ja mukavaa viikonloppua!  
  
Ystävällisin terveisin,  
Onni Salomaa  
  
  
![Diva Galomaa](Attachments/Screenshot%202025-11-09%20at%2022.51.35.png)  
  
